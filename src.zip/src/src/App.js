import React, { Component } from 'react';
import './components/Header/Header.css';
import './components/Header/AOS.css';
import './fonts/font-awesome.min.css';
import AOS from 'aos';
import { BrowserRouter } from 'react-router-dom';
import HeaderNav from './components/Header/HeaderNav/HeaderNav';
import Spinner from './components/Spinner/Spinner'
import axios from 'axios'

export class App extends Component {

  constructor(props) {
    super(props)
    this.state = {
      opened: false,
      load: false,
      bg: false,
      count: 0,
      price: 0,
      order: {
        gamburger: 0,
        limonad: 0,
        palov: 0,
        hotdog: 0,
        juice: 0,
        pizza: 0
      },
      isNull: {
        gamburger: true,
        limonad: true,
        palov: true,
        hotdog: true,
        juice: true,
        pizza: true
      },
      orderNow: true
    }

  }
  componentDidMount() {
    axios.get('https://shohjahon-88bd6-default-rtdb.firebaseio.com')
      .then(response => {
        this.setState({ order: response.data });
      })
      .catch(error => {
        console.log("Prosta error")
      });
  }
  changed = () => {
    this.setState({ bg: !this.state.bg })
  }
  Added = (type) => {
    this.setState((prev) => ({ count: prev.count + 1 }))
    this.setState((prev) => ({ price: prev.price + 1.45 }))
    console.log(this.state.price)
    let items = {
      ...this.state.order
    }
    items[type] = this.state.order[type] + 1;
    this.setState({ order: items })
    let buttonItems = {
      ...this.state.isNull
    }
    if (items[type] > 0) {

      buttonItems[type] = false
      this.setState({
        isNull: buttonItems
      })
    }
    const isNulls = ['gamburger', 'limonad', 'palov', 'hotdog', 'juice', 'pizza']
    let counter = 0
    for (let key in isNulls) {
      if (buttonItems[isNulls[key]]) {
        counter++
        console.log(isNulls[key])
      }
    }
    //let newOrderNow = this.state.orderNow
    if (counter === isNulls.length) {
      //let newOrderNow = true
      this.setState({ orderNow: true })
    }
    else {
      //let newOrderNow = false
      this.setState({ orderNow: false })
    }
  }
  Removed = (type) => {
    this.setState((prev) => ({ count: prev.count - 1 }))
    this.setState((prev) => ({ price: prev.price - 1.45 }))
    console.log(this.state.price)
    let items = {
      ...this.state.order
    }
    items[type] = this.state.order[type] - 1;
    this.setState({ order: items })
    let buttonItems = {
      ...this.state.isNull
    }
    if (items[type] === 0) {

      buttonItems[type] = true
      this.setState({
        isNull: buttonItems
      })
    }
    const isNulls = ['gamburger', 'limonad', 'palov', 'hotdog', 'juice', 'pizza']
    let counter = 0
    for (let key in isNulls) {
      if (buttonItems[isNulls[key]]) {
        counter++
        console.log(isNulls[key])
      }
    }
    if (counter === isNulls.length) {
      //let newOrderNow = true
      this.setState({ orderNow: true })
    }
    else {
      //let newOrderNow = false
      this.setState({ orderNow: false })
    }

  }
  Ordered = () => {
    this.setState({
      load: true
    })
    //alert('You continue!');
    const order = {
      order: this.state.order,
      price: this.state.price,
      customer: {
        name: "Falonchi",
        address: {
          street: "SomeStreet",
          zipCode: "55555",
          country: "Germany"
        },
        email: "urolovshohjahon@gmail.com"
      },
      deliveredMethod: "fastest"
    }
    //console.log('eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee')
    //https://shohjahon-88bd6-default-rtdb.firebaseio.com/ 


    axios.post("https://shohjahon-88bd6-default-rtdb.firebaseio.com/order.json", order)
      .then((res) => {
        console.log(res);
        this.setState({
          load: false
        })
        alert("Buyurtma berildi siz bilan bog'lanamiz...")
      })
      .catch((err) => {
        console.log(err);
        this.setState({
          load: false
        })
        alert("Vaqtinchalik ulanib bo'lmadi...")
      })
  }

  Cleared = () => {
    this.setState({
      count: 0,
      price: 0,
      order: {
        gamburger: 0,
        limonad: 0,
        palov: 0,
        hotdog: 0,
        juice: 0,
        pizza: 0
      },
      isNull: {
        gamburger: true,
        limonad: true,
        palov: true,
        hotdog: true,
        juice: true,
        pizza: true
      },
      orderNow: true
    })
  }
  Opened = () => {
    this.setState({
      opened: true
    })
  }
  Closed = () => {
    this.setState({
      opened: false
    })
  }

  render() {
    let Styled = {
      background: this.state.bg ? 'white' : 'black'
    }
    let Styled2 = {
      color: this.state.bg ? 'black' : 'white',
      fontSize: '24px',
      fontWeight: '700',
      ':hover': {
        color: 'green'
      }
    }
    let menu = {
      display: this.state.opened ? 'block' : 'none',
      width: '100%',
      height: '100%',
      flexDirection: 'column',
      justifyContent: 'space-around',
      alignItems: 'space-around',
      background: 'rgb(93, 15, 194)',
      transition: '0.5s',
      position: 'fixed',
      top: '0px',
      left: '0px'
    }
    let toScreen = null
    if (this.state.order) {
      toScreen = <HeaderNav
        changeBack={this.changed}
        Added={this.Added}
        count={this.state.count}
        price={Math.abs(this.state.price.toFixed(2))}
        order={this.state.order}
        Removed={this.Removed}
        isNull={this.state.isNull}
        Styled2={Styled2}
        orderNow={this.state.orderNow}
        Ordered={this.Ordered}
        Cleared={this.Cleared}
        Opened={this.Opened}
        Closed={this.Closed}
        menu={menu}
      />
    }
    if (this.state.load) {
      toScreen = <Spinner />
    }

    AOS.init()

    return (
      <BrowserRouter>
        <div style={Styled}>
          {
            toScreen
          }
        </div>
      </BrowserRouter >
    )
  }
}

export default App